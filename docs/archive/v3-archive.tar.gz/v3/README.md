# v3 Archive

These documents are from the v3 architecture (monolith-in-a-container, mcp-auth-proxy, bash orchestration).
They are preserved for historical reference. For current architecture, see the v4 spec.

Archived: 2026-03-19 during v4 design.
Lessons from v3 are captured in `docs/v3-retrospective.md`.
